let camera_button = document.querySelector("#hover-button");
let video = document.querySelector("#video");
let click_button = document.querySelector("#click-photo");
let canvas = document.querySelector("#canvas");
let stream;
let intervalId;

camera_button.addEventListener('click', async function() {
  stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
  video.srcObject = stream;
  video.play();

  intervalId = setInterval(capturePhoto, 5000);
  setTimeout(stopRecording, 15000);
});

function capturePhoto() {
  canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
  let image_data_url = canvas.toDataURL('image/jpeg');

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/upload", true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.send(JSON.stringify({
      value: image_data_url
  }));

  canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
}

function stopRecording() {
  clearInterval(intervalId);

  if (stream) {
      let tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
  }
}


window.addEventListener('beforeunload', function() {
  stopRecording();
});