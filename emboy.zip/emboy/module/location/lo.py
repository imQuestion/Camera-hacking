import json
import requests

class get_location:
    
    def __init__(self):
        pass

    def iploc(self ,  ip_address):
        request_url = 'https://geolocation-db.com/jsonp/' + ip_address
        response = requests.get(request_url)
        result = response.content.decode()
        result = result.split("(")[1].strip(")")
        result  = json.loads(result)
        return result