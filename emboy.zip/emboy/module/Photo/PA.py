from io import BytesIO
from PIL import Image
import base64

class Ph:
    def __init__(self):
        pass
    
    def process_image_data(self , image_data):
        encoded_data = image_data.split(",")[1]
        decoded_data = base64.b64decode(encoded_data)
        image = Image.open(BytesIO(decoded_data))
        image.save("emboy.jpg")
