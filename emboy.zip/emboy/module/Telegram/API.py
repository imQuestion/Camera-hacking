import requests

class Tel:
    def __init__(self):
        pass
    
    def send_photo(self ,  bot_token, chat_id, photo_path):
        try:    
            url = f"https://api.telegram.org/bot{bot_token}/sendPhoto"
            files = {'photo': open(photo_path, 'rb')}
            data = {'chat_id': chat_id}
            response = requests.post(url, files=files, data=data)
            return response.status_code
        except:
            return "ERROR"
    
    def send_message(self , text, CHAT_ID, BOT_TOKEN):
        try:    
            url = f'https://api.telegram.org/bot{BOT_TOKEN}/sendMessage'
            params = {
            'chat_id': CHAT_ID,
            'text': text
            }
            response = requests.post(url, data=params)
            return response.status_code
        except:
            return "ERROR"
        